<?php
// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    
    // Recoger los valores del formulario
    $fullname = isset($_POST['fullname']) ? htmlspecialchars(trim($_POST['fullname'])) : '';
    $email = isset($_POST['email']) ? htmlspecialchars(trim($_POST['email'])) : '';
    $telefono = isset($_POST['telefono']) ? htmlspecialchars(trim($_POST['telefono'])) : '';
    $empresa = isset($_POST['empresa']) ? htmlspecialchars(trim($_POST['empresa'])) : '';
    $mensaje = isset($_POST['mensaje']) ? htmlspecialchars(trim($_POST['mensaje'])) : '';
    $temas = isset($_POST['tema']) ? $_POST['tema'] : []; // Los valores seleccionados de los checkboxes
    
    // Validar que se ha llenado el campo del correo
    if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        
        // Destinatario del correo 
        $to1 = "programacion@tendenzeperu.com";  // Primer destinatario
        $to2 = "karinahigashi@tendenzeperu.com"; // Segundo destinatario
        // Asunto del correo
        $subject = "New contact message - tendenzeperu.com";
        
        // Construir el cuerpo del mensaje
        $message = "New message sent from the contact form:\n\n";
        $message .= "Name: " . $fullname . "\n";
        $message .= "Email: " . $email . "\n";
        $message .= "Phone: " . $telefono . "\n";
        $message .= "Company: " . $empresa . "\n";
        $message .= "Message: " . $mensaje . "\n";
        $message .= "Interested in: " . implode(', ', $temas) . "\n"; // Unir los temas seleccionados en una cadena
        
        // Encabezados del correo
        $headers = "From: " . $email . "\r\n";
        $headers .= "Reply-To: " . $email . "\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        
        // Enviar el correo al primer destinatario
        $mailSent1 = mail($to1, $subject, $message, $headers);

        // Enviar el correo al segundo destinatario
        $mailSent2 = mail($to2, $subject, $message, $headers);

        // Verificar si ambos correos fueron enviados con éxito
        if ($mailSent1 && $mailSent2) {
            echo json_encode([
                'success' => true,
                'message' => 'The message has been sent successfully.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'There was an error sending the message.'
            ]);
        }
        
    } else { 
        echo json_encode([
            'success' => false,
            'message' => 'There was an error sendingPlease provide a valid email address.'
        ]);
    }
} else { 
    echo json_encode([
        'success' => false,
        'message' => 'There was a problem submitting the form.'
    ]);
}
?>
